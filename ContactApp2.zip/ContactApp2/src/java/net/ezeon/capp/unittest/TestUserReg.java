/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.ezeon.capp.unittest;

import net.ezeon.capp.domain.User;
import net.ezeon.capp.service.HibernateUtil;
import net.ezeon.capp.service.UserService;
import org.hibernate.Hibernate;

/**
 *
 * @author Arvind
 */
public class TestUserReg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        UserService service = new UserService();
        
        User u = new User();
        u.setName("nupur");
        u.setPhone("9876543210");
        u.setEmail("nup@gmail.com");
        u.setAddress("Bhopal");
        u.setUsername("nup");
        u.setPassword("nup123");
        u.setRole(UserService.ROLE_ADMIN);
        u.setStatus(UserService.LOGIN_ACTIVE);
        service.register(u);
        HibernateUtil.getSessionFactory().close();
        
    }
    
}
