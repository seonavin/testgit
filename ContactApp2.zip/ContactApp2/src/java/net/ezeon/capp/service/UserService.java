/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.ezeon.capp.service;

import java.util.List;
import net.ezeon.capp.domain.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author Arvind
 */
public class UserService {
    public static final int ROLE_ADMIN = 1;
    public static final int ROLE_USER =2;
     
    public static final int LOGIN_ACTIVE = 1;
    public static final int LOGIN_BLOCK =2;
    
    SessionFactory sf =HibernateUtil.getSessionFactory();
    
    public void register(User u){
        
        Session hses = sf.openSession();
        try{
            Transaction tx = hses.beginTransaction();
            hses.save(u);
            tx.commit();
            
        }finally{
            hses.close();
        }
        
    }
    /**
     * The method authenticates the user for given credentials.
     * If authentication is success then return User object else return null.
     * @param username
     * @param password
     * @return 
     */
    public User login(String username, String password){
        
        String hql ="from User where userName =:un and password =:pw";
        Session hses = sf.openSession();
        try{
            Transaction tx = hses.beginTransaction();
            Query q =hses.createQuery(hql);
            q.setParameter("un", username);
            q.setParameter("pw", password);
            List<User> list =q.list();
            if(list!=null && list.size()==1){
               return list.get(0);
            }
            
            tx.commit();
            
        }finally{
            hses.close();
        }
       return null; //todo
    }
    public List<User> findAll(){
        String hql ="from User order by name asc";
        Session hses =sf.openSession();
        try{
            Query q =hses.createQuery(hql);
            return q.list();
            
        }finally{
            hses.close();
        }
    }
    public void changeStatus(Integer userId,Integer status){
        Session hses =sf.openSession();
        try{
            Transaction tx =hses.beginTransaction();
            User user = (User) hses.get(User.class,userId);
            user.setStatus(status);
            hses.saveOrUpdate(user); //not required because user object is in persistant state and its now-modified (DIRTY Object). Its automatically updated during tx-commit

            tx.commit();
        }finally{
            hses.close();
        }
    }
    
}
