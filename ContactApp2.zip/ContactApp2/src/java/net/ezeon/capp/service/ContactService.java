/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.ezeon.capp.service;

import java.util.List;
import net.ezeon.capp.domain.Contact;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *This class contains operations related to contact entity.
 * @author Arvind
 */
public class ContactService {
    SessionFactory sf =HibernateUtil.getSessionFactory();
    
    public void save(Contact c) {
        Session hses = sf.openSession();
        try {
            Transaction tx = hses.beginTransaction();
            hses.save(c);
            tx.commit();
        } finally {
            hses.close();
        }
    }
    public void update(Contact c){
        Session hses = sf.openSession();
        try {
            Transaction tx = hses.beginTransaction();
            hses.saveOrUpdate(c);
            tx.commit();
        } finally {
            hses.close();
        }
    }
    public void delete(Integer contactId){
       Session hses = sf.openSession();
        try {
            Transaction tx = hses.beginTransaction();
            Contact c= (Contact) hses.get(Contact.class,contactId);
            hses.delete(c);
            tx.commit();
        } finally {
            hses.close();
        }
    }
    public Contact findById(Integer contactId){
        
       Session hses = sf.openSession();
        try {
           return (Contact) hses.get(Contact.class,contactId);
            
        } finally {
            hses.close();
        }
    }
    
     /**
     * Find all contact for given userId, its generally logged in userId.
     *
     * @param userId logged in userId
     * @return all list of contacts for given userId
     */
    public List<Contact> findUserContacts(Integer userId) {
        String hql="from Contact where userId =:uid";
        Session hses= sf.openSession();
        try{
            Query q = hses.createQuery(hql);
            q.setInteger("uid",userId);
            return q.list();
            
        }finally{
            hses.close();
        }
     
    }
  public List<Contact> search(Integer userId, String criteria) {
     // String hql ="from Contact where userId =:uid AND (name LIKE '%"+criteria+"%'" OR phone LIKE '%"+criteria+"%'"OR email LIKE '%"+criteria+"%'" OR address LIKE '%"+criteria+"%'" OR remark LIKE '%"+criteria+"%')";
      return null;//todo
  }
    
}
