/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.ezeon.capp.service;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Arvind
 */
@WebFilter(filterName = "SecurityFilter", urlPatterns = {"/deleteAction.jsp","/editViewAction.jsp","/saveAction.jsp"})
public class SecurityFilter implements Filter {
    
   
    private FilterConfig filterConfig = null;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
           this.filterConfig=filterConfig;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req =(HttpServletRequest) request;
        HttpServletResponse resp= (HttpServletResponse) response;
        System.out.println("------do filter------");
        HttpSession session=req.getSession();
        Integer userId =(Integer)session.getAttribute("userId");
         
        if(userId== null){
            //deny- unaothorized user
            resp.sendRedirect("index.jsp?act=ad");//ad - access deny
            return;
            
        }else
            //allow
            chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        
    }
    
     
    
    
}